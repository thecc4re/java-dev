function cookieinfo(){
   /* chrome.cookies.getAll({},function (cookie){
        console.log(cookie.length);
        for(i=0;i<cookie.length;i++){
            //console.log(JSON.stringify(cookie[i]));
        }
    });
    chrome.cookies.getAllCookieStores(function (cookiestores){
        for(i=0;i<cookiestores.length;i++){
           // console.log(JSON.stringify(cookiestores[i]));
        }
    });
    chrome.cookies.set({"name":"Sample1","url":"http://developer.chrome.com/extensions/cookies.html","value":"Dummy Data"},function (cookie){
        //console.log(JSON.stringify(cookie));
       // console.log(chrome.extension.lastError);
       // console.log(chrome.runtime.lastError);
    });
    chrome.cookies.onChanged.addListener(function (changeInfo){
       // console.log(JSON.stringify(changeInfo));
    });*/
}

function baseCookieUtils(){
    
    return {
        readCookieData :  (cd)=>{
            destUrl="https://matches.keralamatrimony.com";
            chrome.cookies.getAll(cd,function (cookie){
                if(cookie.length>0)
                console.log((cookie[0].value));
                chrome.cookies.set({"name":"Sample1","url": destUrl,
                "value":cookie[0].value},
                function (cookie){
                    console.log("done"+cookie.value);
                    //navigator.clipboard.writeText("location");
                    var crui="";
                 

                chrome.tabs.query({currentWindow: true, active: true}, function(tabs){
                    console.log(tabs[0].url);
                    chrome.tabs.update(undefined, {url: tabs[0].url+"#"+cookie.value});
                });

                    
                    document.execCommand('paste');
                    });
            });     

    },
    setCookieData : (uri)=>{
        console.log("setting cookie data"+uri);
    } 


};
     
}


window.onload=cookieinfo;