document.addEventListener('DOMContentLoaded', function() {
    var checkPageButton = document.getElementById('checkPage');
    checkPageButton.addEventListener('click', function() {
    
      
             
               // chrome.extension.getBackgroundPage().cookieinfo();
                var cd =   new Object();
                cd.name="_gid";
                cd.url="https://matches.keralamatrimony.com/";
                
                chrome.extension.getBackgroundPage().baseCookieUtils().readCookieData(cd);

    }, false);






  }, false);


