package com.cvs.pci.disagg.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.PersistenceConstructor;
import org.springframework.data.gemfire.mapping.annotation.Region;

import java.io.Serializable;


@Region(value="FacilityData")
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor @ToString
public class FacilityData implements Serializable {
    @PersistenceConstructor
    public FacilityData(CompositeKey key, String value) {
        this.key = key;
        this.value = value;
        this.key1 = key.getKey1();
        this.key2 = key.getKey2();
    }

    @Id @NonNull
    @Getter
    private CompositeKey key;
    public void setKey(CompositeKey key){
        this.key = key;
        this.key1 = key.getKey1();
        this.key2 = key.getKey2();
    }
    @Getter @Setter
    private String key1;
    @Getter @Setter
    private String key2;
    @Getter @Setter
    private String value;

}
