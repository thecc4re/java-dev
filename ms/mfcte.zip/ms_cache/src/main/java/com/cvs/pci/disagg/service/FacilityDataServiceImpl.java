package com.cvs.pci.disagg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cvs.pci.disagg.model.CompositeKey;
import com.cvs.pci.disagg.model.FacilityData;
import com.cvs.pci.disagg.repository.FacilityDataRepository;

@Service
public class FacilityDataServiceImpl implements FacilityDataService<FacilityData> {
    private final
    FacilityDataRepository facilityDataRepository;

    public FacilityDataServiceImpl(FacilityDataRepository facilityDataRepository) {
        this.facilityDataRepository = facilityDataRepository;
    }

    @Override
    public Iterable<FacilityData> findAll() {
        return facilityDataRepository.findAll();
    }

    @Override
    public Optional<FacilityData> findByKey(CompositeKey key) {
        return facilityDataRepository.findById(key);
    }

    @Override
    public void deleteAll() {
        facilityDataRepository.deleteAll();
    }

    @Override
    public void save(FacilityData facilityData) {
        facilityDataRepository.save(facilityData);
    }

    @Override
    public void saveAll(List<FacilityData> list) {
        facilityDataRepository.saveAll(list);
    }
}
