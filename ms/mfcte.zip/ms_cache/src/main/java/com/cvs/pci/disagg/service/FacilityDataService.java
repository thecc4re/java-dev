package com.cvs.pci.disagg.service;

import com.cvs.pci.disagg.model.CompositeKey;

import java.util.List;
import java.util.Optional;

public interface FacilityDataService<T> {
    Iterable<T> findAll();
    Optional<T> findByKey(CompositeKey key);
    void deleteAll();
    void save(T t);
    void saveAll(List<T> list);
}
