package com.cvs.pci.disagg.repository;

import java.util.List;

import org.springframework.data.gemfire.repository.query.annotation.Trace;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cvs.pci.disagg.model.GenericCache;

@Repository
public interface GenericRepository<T>   extends CrudRepository<GenericCache<T>, String> {

		@Trace
		String findByIdxKey(String idxkey);
		
		@Trace
		 List<GenericCache<T>> findAllByIdxKey(String idxkey);
	}
		

