package com.cvs.pci.disagg.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.validation.Valid;

import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cvs.pci.disagg.logger.LoggerUtil;
import com.cvs.pci.disagg.model.GenericCache;
import com.cvs.pci.disagg.service.CacheService;
import com.cvs.pci.disagg.util.MsCacheUtils;
import com.cvs.pci.disagg.utils.BaseConfigs.CacheStatus;
import com.cvs.pci.disagg.utils.Loggable;
import com.cvs.pci.disagg.vo.CacheRequestVO;
import com.cvs.pci.disagg.vo.CacheResponseVO;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/v1.0.0/")
public class GenericCacheController {
	@Autowired
	@Qualifier("genericCache")
	CacheService<GenericCache, String> genericCacheService;
	
	@PutMapping(path = "/store", consumes = "application/json", produces = "application/json")
	@CrossOrigin(origins = "*")
	@Loggable
	public CacheResponseVO cacheStoreAction(@Valid @RequestBody CacheRequestVO rqstvo) {
		LoggerUtil.printMethodStart(this, Level.INFO, "cacheStoreAction ", "", "");
		CacheResponseVO cacheresponse = new CacheResponseVO();
		ObjectMapper obmapper = new ObjectMapper();
		try {
			LoggerUtil.printLog(this, Level.DEBUG, null, "cacheStoreAction request data", rqstvo.getData().toString());
			GenericCache qp = new GenericCache(rqstvo.getIdxKey(), rqstvo.getData());
			genericCacheService.save(qp);
			MsCacheUtils.setStatus(cacheresponse, CacheStatus.OP_SUCESS);
		} catch (Exception e) {
			LoggerUtil.printLog(this, Level.ERROR, null, "Exception on cacheStoreAction", e.toString());
			MsCacheUtils.setStatus(cacheresponse, CacheStatus.ERR);
			e.printStackTrace();
		}
		LoggerUtil.printMethodEnd(this, Level.INFO, "cacheStoreAction", "", "");
		return cacheresponse;
	}
	
	@PutMapping(path = "/storeAll", consumes = "application/json", produces = "application/json")
	@CrossOrigin(origins = "*")
	@Loggable
	public CacheResponseVO cacheStoreAllAction(@Valid @RequestBody CacheRequestVO rqstvo) {
		LoggerUtil.printMethodStart(this, Level.INFO, "cacheStoreAllAction ", "", "");
		CacheResponseVO cacheresponse = new CacheResponseVO();
		ObjectMapper obmapper = new ObjectMapper();
		List<String> pushlist = new ArrayList<String>(1);
		if (!rqstvo.getMultidata().isEmpty())
			try {
				rqstvo.getMultidata().stream().forEach(item -> {
					if (!item.getIdxKey().isEmpty()) {
						genericCacheService.save(item);
						pushlist.add(item.getIdxKey());
					}
				});
				cacheresponse.setPushlist(pushlist);
				MsCacheUtils.setStatus(cacheresponse, CacheStatus.OP_BULK_SUCESS);
			} catch (Exception e) {
				LoggerUtil.printLog(this, Level.ERROR, null, "Exception on cacheStoreAllAction", e.toString());
				MsCacheUtils.setStatus(cacheresponse, CacheStatus.ERR);
				e.printStackTrace();
			}
		LoggerUtil.printMethodEnd(this, Level.INFO, "cacheStoreAllAction", "", "");
		return cacheresponse;
	}
	
	@PostMapping(path = "/flush/{idxKey}", consumes = "application/json", produces = "application/json")
	@CrossOrigin(origins = "*")
	@Loggable
	public CacheResponseVO cacheDeleteAction(@Valid @PathVariable String idxKey) {
		CacheResponseVO cacheresponse = new CacheResponseVO();
		try {
			LoggerUtil.printMethodEnd(this, Level.INFO, "cacheDeleteAction", "", "");
			boolean returnval = genericCacheService.delete(idxKey);
			cacheresponse.setIdxKey(idxKey);
			if (returnval) {
				MsCacheUtils.setStatus(cacheresponse, CacheStatus.OP_DEL_SUCESS);
			}
		} catch (Exception e) {
			LoggerUtil.printLog(this, Level.ERROR, null, "Exception on cacheDeleteAction", e.toString());
			MsCacheUtils.setStatus(cacheresponse, CacheStatus.ERR);
			e.printStackTrace();
		}
		LoggerUtil.printMethodEnd(this, Level.INFO, "cacheDeleteAction", "", "");
		return cacheresponse;
	}
	
	@PostMapping(path = "/fetch", consumes = "application/json", produces = "application/json")
	@CrossOrigin(origins = "*")
	@Loggable
	public CacheResponseVO cachePullAction(@Valid @RequestBody CacheRequestVO rqstvo) {
		CacheResponseVO cacheresponse = new CacheResponseVO();
		LoggerUtil.printMethodEnd(this, Level.INFO, "cachePullAction", "", "");
		try {
			Optional<GenericCache> cachepullVal = genericCacheService.findByKey(rqstvo.getIdxKey());
			cacheresponse.setIdxKey(rqstvo.getIdxKey());
			if (cachepullVal.isPresent()) {
				GenericCache genericcache = cachepullVal.get();
				cacheresponse.setData(genericcache.getPayload());
				MsCacheUtils.setStatus(cacheresponse, CacheStatus.SUCCESS);
			} else {
				MsCacheUtils.setStatus(cacheresponse, CacheStatus.FAIL);
			}
		} catch (Exception e) {
			LoggerUtil.printLog(this, Level.ERROR, null, "Exception on cachePullAction", e.toString());
			MsCacheUtils.setStatus(cacheresponse, CacheStatus.ERR);
			e.printStackTrace();
		}
		LoggerUtil.printMethodEnd(this, Level.INFO, "cachePullAction", "", "");
		return cacheresponse;
	}
	
	@PostMapping(path = "/fetchAll", consumes = "application/json", produces = "application/json")
	@CrossOrigin(origins = "*")
	@Loggable
	public CacheResponseVO cachePullAllAction(@Valid @RequestBody CacheRequestVO rqstvo) {
		CacheResponseVO cacheresponse = new CacheResponseVO();
		LoggerUtil.printMethodEnd(this, Level.INFO, "cachePullAllAction", "", "");
		try {
			Iterable<GenericCache> cachePullVal = genericCacheService.findAllByKeys(rqstvo.getIdxKeyGroup());
			cacheresponse.setIdxKey(rqstvo.getIdxKey());
			cacheresponse.setData(StreamSupport.stream(cachePullVal.spliterator(), false).collect(Collectors.toList()));
			cacheresponse.setMissedEntry(genericCacheService.findMissedCache(cachePullVal, rqstvo.getIdxKeyGroup()));
			MsCacheUtils.setStatus(cacheresponse, CacheStatus.SUCCESS);
		} catch (Exception e) {
			LoggerUtil.printLog(this, Level.ERROR, null, "Exception on cachePullAllAction", e.toString());
			MsCacheUtils.setStatus(cacheresponse, CacheStatus.ERR);
			e.printStackTrace();
		}
		LoggerUtil.printMethodEnd(this, Level.INFO, "cachePullAllAction", "", "");
		return cacheresponse;
	}
}
