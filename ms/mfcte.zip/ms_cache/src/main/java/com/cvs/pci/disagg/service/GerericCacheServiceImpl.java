package com.cvs.pci.disagg.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.cvs.pci.disagg.model.GenericCache;
import com.cvs.pci.disagg.repository.GenericRepository;

@Service
@Qualifier("genericCache")
public class GerericCacheServiceImpl<T> implements CacheService<GenericCache<T>, String> {

	@Autowired
	private GenericRepository genericrepo;

	@Override
	public Optional<GenericCache<T>> findByKey(String k) {

		return genericrepo.findById(k);
	}

	@Override
	public void save(GenericCache t) {
		genericrepo.save(t);
	}

	@Override
	public boolean delete(String idxKey) {
		genericrepo.deleteById(idxKey);
		return true;
	}

	@Override
	public Iterable<GenericCache<T>> findAllByKeys(List<String> k) {
		return genericrepo.findAllById(k);
	}

	@Override
	public List<String> findMissedCache(Iterable<GenericCache<T>> cacheitems, List<String> keys) {
		try {
			List<String> foundItems = StreamSupport.stream(cacheitems.spliterator(), false).map(x -> x.getIdxKey())
					.collect(Collectors.toList());
			List<String> missedItems = new ArrayList(keys);
			missedItems.removeAll(foundItems);
			return missedItems;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
