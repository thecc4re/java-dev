package com.cvs.pci.disagg.repository;

import java.util.Collection;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cvs.pci.disagg.model.CompositeKey;
import com.cvs.pci.disagg.model.FacilityData;

@Repository
public interface FacilityDataRepository extends CrudRepository<FacilityData, CompositeKey> {
    Collection<FacilityData> findByKey1(String key);
    Collection<FacilityData> findByKey2(String key);
    FacilityData findByKey1AndKey2(String key1, String key2);
    Collection<FacilityData> findByKey1Contains(String key);
    Collection<FacilityData> findByKey2Contains(String key);
    Collection<FacilityData> findByKey1ContainsAndKey2Contains(String key1, String key2);
    Collection<FacilityData> findByValue(String value);
    Collection<FacilityData> findByValueContains(String value);
}
