package com.cvs.pci.disagg.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cvs.pci.disagg.model.CompositeKey;
import com.cvs.pci.disagg.model.FacilityData;
import com.cvs.pci.disagg.service.FacilityDataService;

@RestController
@RequestMapping("/cache")
public class FacilityDataController {

    private final
    FacilityDataService<FacilityData> facilityDataService;

    public FacilityDataController(FacilityDataService<FacilityData> facilityDataService) {
        this.facilityDataService = facilityDataService;
    }


    @GetMapping("/facilitydata")
    @CrossOrigin(origins = "*")
    public Iterable<FacilityData> readAll() {
        return facilityDataService.findAll();
    }

    @GetMapping("/facilitydata/{key1}/{key2}")
    @CrossOrigin(origins = "*")
    public FacilityData readById(@PathVariable(value="key1")String key1,
                                 @PathVariable(value="key2")String key2) {
        Optional<FacilityData> optionalFacilityData = facilityDataService.findByKey(new CompositeKey(key1,key2));
        return optionalFacilityData.orElse(null);
    }

    @PostMapping(path="/facilitydata", consumes = "application/json", produces = "application/json")
    @CrossOrigin(origins = "*")
    public void persistAll(@RequestBody List<FacilityData> facilityDataList) {
        facilityDataService.saveAll(facilityDataList);
    }

    @DeleteMapping("/facilitydata")
    @CrossOrigin(origins = "*")
    public void deleteAll() {
        facilityDataService.deleteAll();
    }

}
