package com.cvs.pci.disagg.service;


import java.util.List;
import java.util.Optional;

public interface CacheService<T,K> {
 public Optional<T> findByKey(K k);
 public Iterable<T> findAllByKeys(List<K> k);
 public void save(T t);
 public boolean delete(K idxKey);
 public List<K> findMissedCache(Iterable<T> cacheitems,List<K> keys) ;
}
