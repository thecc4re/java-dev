package com.cvs.pci.disagg.util;

import com.cvs.pci.disagg.utils.BaseConfigs;
import com.cvs.pci.disagg.vo.CacheResponseVO;

public class MsCacheUtils {
	
	public static void setStatus(CacheResponseVO cvo , BaseConfigs.CacheStatus status)
	{
		cvo.setStatus(status.getStatusDesc());
		cvo.setStatusCode(status.getStatusCode());
	}

}
