package com.cvs.pci.disagg;


import org.apache.geode.cache.client.ClientRegionShortcut;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.gemfire.config.annotation.ClientCacheApplication;
import org.springframework.data.gemfire.config.annotation.ClientCacheApplication.Locator;
import org.springframework.data.gemfire.config.annotation.EnableEntityDefinedRegions;
import org.springframework.data.gemfire.repository.config.EnableGemfireRepositories;

import com.cvs.pci.disagg.model.FacilityData;

@SpringBootApplication
@EnableGemfireRepositories
//@EnableHttpService
//@EnableLocator
//@EnableManager
/*@ClientCacheApplication(name = "CacheApplication", logLevel = "error", locators = {
	    @Locator(host = "thecc4re.local",port =10334 )
	})*/
//@CacheServerApplication(locators = "localhost[10334]")

@ClientCacheApplication(name = "CacheApplication", logLevel = "error")

@EnableEntityDefinedRegions(basePackageClasses = FacilityData.class,
        clientRegionShortcut = ClientRegionShortcut.LOCAL)
public class CacheApplication {

    public static void main(String... args) {
        SpringApplication.run(CacheApplication.class, args);
    }
}

