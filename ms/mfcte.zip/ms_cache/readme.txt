{
    "action": "insert",
    "region": "local",
    "idxKey": "",
    "data": {
        "questions": [
            {
                "questionnaireId": 1,
                "questionnaireVersion": 1,
                "questionnaireDescription": "DIAEBETES DATA COLLECTION - A1C",
                "questionnaireGroup": "DIAEBETES DATA COLLECTION - A1C - GROUP 1",
                "questionId": 1,
                "questionLevel": 1,
                "questionSeq": 1,
                "questionCategory": null,
                "parentQuestionId": null,
                "mandatoryInd": "Y",
                "questionText": "Have you ever had your A1C Tested?",
                "opptyOutputInd": "Y",
                "answerType": "Single Choice"
            },
            {
                "questionnaireId": 1,
                "questionnaireVersion": 1,
                "questionnaireDescription": "DIAEBETES DATA COLLECTION - A1C",
                "questionnaireGroup": "DIAEBETES DATA COLLECTION - A1C - GROUP 1",
                "questionId": 2,
                "questionLevel": 1,
                "questionSeq": 2,
                "questionCategory": null,
                "parentQuestionId": null,
                "mandatoryInd": "Y",
                "questionText": "Do you know the month and year of your most recent A1C test?",
                "opptyOutputInd": "N",
                "answerType": "Single Choice"
            }
        ],
        "answers": [
            {
                "questionnaireId": 1,
                "questionnaireVersion": 1,
                "questionId": 1,
                "answerSeqNbr": 1,
                "answerMinValue": "Yes",
                "answerMaxValue": null
            },
            {
                "questionnaireId": 1,
                "questionnaireVersion": 1,
                "questionId": 1,
                "answerSeqNbr": 2,
                "answerMinValue": "No",
                "answerMaxValue": null
            }
        ],
        "answerTrigger": [
            {
                "questionnaireId": 1,
                "questionnaireVersion": 1,
                "parentQuestionId": 2,
                "triggerSeqNbr": 1,
                "questionId": 5,
                "trigAnswerMinVal": "January 2019",
                "trigAnswerMaxVal": null,
                "trigAnswerOperand": "="
            },
            {
                "questionnaireId": 1,
                "questionnaireVersion": 1,
                "parentQuestionId": 2,
                "triggerSeqNbr": 2,
                "questionId": 6,
                "trigAnswerMinVal": "January 2019",
                "trigAnswerMaxVal": null,
                "trigAnswerOperand": "="
            }
        ]
    }
}