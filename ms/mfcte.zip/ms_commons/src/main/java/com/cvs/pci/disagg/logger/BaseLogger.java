package com.cvs.pci.disagg.logger;

import java.util.HashMap;
/**
 * @author CVS
 *
 */
public abstract class BaseLogger {


	/*
	 * Global interface to store all class loggers
	 */
	private static final HashMap<String, org.slf4j.Logger> classLoggerMap = new HashMap<String, org.slf4j.Logger> (16); 

	/**
	 * @param cls passing the class  
	 * @return
	 */
	protected static  org.slf4j.Logger getClassLogger(Class cls){

		if(!classLoggerMap.containsKey(cls.getName()) || classLoggerMap.get(cls.getName())== null){
			classLoggerMap.put(cls.getName(), org.slf4j.LoggerFactory.getLogger(cls));
		} 
		return classLoggerMap.get(cls.getName());
	}

	/**
	 * @param object passing the object itself  
	 * @return
	 */
	protected static org.slf4j.Logger getClassLogger(Object object){

		if(!classLoggerMap.containsKey(object.getClass().getName()) || classLoggerMap.get(object.getClass().getName())== null){
			classLoggerMap.put(object.getClass().getName(), org.slf4j.LoggerFactory.getLogger(object.getClass()));
		} 
		return classLoggerMap.get(object.getClass().getName());
	}
}

