package com.cvs.pci.disagg.vo;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BaseCache {

	
	@NotNull(message = "idxKey is missing")
	@JsonProperty("idxKey")
	protected String idxKey;
	
	
	@JsonProperty("idxKeyGroup")
	protected List<String> idxKeyGroup;



	
	
}
