package com.cvs.pci.disagg.model;


import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.PersistenceConstructor;
import org.springframework.data.gemfire.config.annotation.EnablePdx;
import org.springframework.data.gemfire.mapping.annotation.Region;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;
import lombok.ToString;


@Region(value="GC_CACHE") 
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor @ToString
@EnablePdx 
public class GenericCache<T> implements Serializable {
            
	private static final long serialVersionUID = 78934569038L;  
	
	@PersistenceConstructor 
    public GenericCache(@NonNull String idxKey, T qpack) {
		super();
		this.idxKey = idxKey;
		this.payload = qpack;
	}
	@Getter @Setter 
    @Id @NonNull
    private String idxKey;
	
	
    @Getter @Setter
    private T payload;
    
   

}
