package com.cvs.pci.disagg.utils;

public class BaseConfigs {

	public enum CacheStatus {
	    SUCCESS  (200,"IN_CACHE"),    
	    FAIL   (300,"NOT_FOUND")   ,
	    ERR   (400,"CACHE_EXCEP")  ,
	    OP_SUCESS(201,"PUSHED_TO_CACHE"),
	    OP_BULK_SUCESS(202,"BULK_PUSHED_TO_CACHE"),
	    OP_DEL_SUCESS(210,"DELETE_FROM_CACHE")
	    
	    ;  
	    private final int statusCode;
	    private final String statusDesc;

	    private CacheStatus(int levelCode,String sdesc) {
	        this.statusCode = levelCode;
	        this.statusDesc=sdesc;
	    }

		public int getStatusCode() {
			return statusCode;
		}

		public String getStatusDesc() {
			return statusDesc;
		}
	}
	
	
	
	public enum CacheOps {
	    PUSH  (200,"PUSH"),
	    DELETE  (300,"DELETE")   ,
	    FLUSH   (300,"FLUSH")   ,
	    UPDATE   (400,"UPDATE")  ,
	    ;  
	    private final int actionCode;
	    private final String actionVal;

	    private CacheOps(int code,String val) {
	        this.actionCode = code;
	        this.actionVal=val;
	    }

		public int getActionCode() {
			return actionCode;
		}

		public String getActionVal() {
			return actionVal;
		}
	    
	}
	
}
