package com.cvs.pci.disagg.vo;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.cvs.pci.disagg.model.GenericCache;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CacheRequestVO extends BaseCache {

	@NotNull
	@JsonProperty("action")
	private String action;
	
	@JsonProperty("region")
	private String region;

	@JsonProperty("data")
	private Object data;

	@JsonProperty("dataList")
	private List<GenericCache<Object>> multidata;
	
	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public List<GenericCache<Object>> getMultidata() {
		return multidata;
	}

	public void setMultidata(List<GenericCache<Object>> multidata) {
		this.multidata = multidata;
	}

	public String getIdxKey() {
		return idxKey;
	}

	public void setIdxKey(String idxKey) {
		this.idxKey = idxKey;
	}
 
	public List<String> getIdxKeyGroup() {
		return idxKeyGroup;
	}


	public void setIdxKeyGroup(List<String> idxKeyGroup) {
		this.idxKeyGroup = idxKeyGroup;
	}

	@Override
	public String toString() {
		return "CacheRequestVO [action=" + action + ", region=" + region + ", data=" + data + ", multidata=" + multidata
				+ ", idxKey=" + idxKey + ", idxKeyGroup=" + idxKeyGroup + "]";
	}
	

}
