package com.cvs.pci.disagg.logger;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.slf4j.event.Level;

public class LoggerUtil extends BaseLogger     {
	private static final Logger LOGGER = LoggerFactory.getLogger(LoggerUtil.class);
	static String GLOBAL_CONSOLE_LOG_DATE_FORMAT = "yyyy/MM/dd HH:mm:ss,SSS";
	private static final DateFormat dateFormat = new SimpleDateFormat(GLOBAL_CONSOLE_LOG_DATE_FORMAT );
	static String GLOBAL_DEFAULT_LOG_LEVEL = "SYSOUT";
	static String GLOBAL_LOG_MESSAGE_DELIMITER = "::";
	/**
	 * 
	 * @param logger	
	 * @param level
	 * @param MsgText
	 */
	public static final void print(Logger logger, String level, String MsgText){

		try {
			MDC.put("IP",InetAddress.getLocalHost().getHostAddress());

			logger = (logger == null) ?  LOGGER :  logger ;
			level = (level == null) ?  GLOBAL_DEFAULT_LOG_LEVEL :  level ;
			String cleanText = MsgText.replace('\n',' ').replace('\r',' ').replace('\f', ' ');
			
			switch(level) {
			case "SYSOUT" 	:   System.out.println( dateFormat.format(new Date()) +" "+logger.getName() +" - " +  MsgText ); break;
			case "SYSERROR" : 	System.err.println( dateFormat.format(new Date()) +" "+logger.getName() +" - " +  MsgText ); break;
			case "TRACE" : logger.trace(logger.getName() +"::"+cleanText); break;
			case "DEBUG" : logger.debug(logger.getName() +"::"+cleanText); break;
			case "INFO"  : logger.info(logger.getName() +"::"+cleanText);  break;
			case "WARN"  : logger.warn(logger.getName() +"::"+cleanText);  break;
			case "ERROR" : logger.error(logger.getName() +"::"+cleanText); break;
			default 	 : System.out.println( dateFormat.format(new Date()) + " - " + MsgText ); break;
			}
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} 	    
	}
	
	
	/**
	 * @param object
	 * @param level
	 * @param args
	 * @param userContextDTO
	 */
	public static void printLog(Object object , Level level, UserContextDTO userContextDTO, String... args) {

		print(getClassLogger(object), level.toString(),  createAppMsgText(args)+ "facilityID="+getFacilityID(userContextDTO));

	}
	
	/**
	 * @param cls
	 * @param level
	 * @param args
	 * @param userContextDTO
	 */
	public static void printLog(Class cls , Level level, UserContextDTO userContextDTO, String... args) {

		print(getClassLogger(cls), level.toString(), createAppMsgText(args)+ "facilityID="+getFacilityID(userContextDTO));

	}

	/**
	 * @param cls
	 * @param level
	 * @param args
	 * @param userContextDTO
	 */
	public static void printLog(Class cls , Level level, String facilityId, String... args) {

		print(getClassLogger(cls), level.toString(), createAppMsgText(args)+ "facilityID="+facilityId);

	}
	
	/**
	 * 
	 * @param classLogger
	 * @param level
	 * @param methodName
	 * @param userContextDTO
	 * @param createAppMsgText
	 */
	public static void printMethodStart(Object object, Level level, String methodName, UserContextDTO userContextDTO, String...args ) {

		print(getClassLogger(object), level.toString(), methodName + GLOBAL_LOG_MESSAGE_DELIMITER + "START" + GLOBAL_LOG_MESSAGE_DELIMITER + createAppMsgText(args)+"facilityID="+getFacilityID(userContextDTO));

	}
	
	
	/**
	 * 
	 * @param classLogger
	 * @param level
	 * @param methodName
	 * @param facilityId
	 * @param createAppMsgText
	 */
	public static void printMethodStart(Object object, Level level, String methodName, String facilityId, String...args ) {

		print(getClassLogger(object), level.toString(), methodName + GLOBAL_LOG_MESSAGE_DELIMITER + "START" + GLOBAL_LOG_MESSAGE_DELIMITER + createAppMsgText(args)+"facilityID="+facilityId);

	}
	
	/**
	 * @param object
	 * @param level
	 * @param methodName
	 * @param userContextDTO
	 * @param args
	 */
	public static void printMethodEnd(Object object , Level level, String methodName, UserContextDTO userContextDTO, String... args) {

		print(getClassLogger(object), level.toString(), methodName + GLOBAL_LOG_MESSAGE_DELIMITER + "END" + GLOBAL_LOG_MESSAGE_DELIMITER + createAppMsgText(args)+"facilityID="+getFacilityID(userContextDTO));

	}  
	
	
	/**
	 * @param object
	 * @param level
	 * @param methodName
	 * @param facilityId
	 * @param args
	 */
	public static void printMethodEnd(Object object , Level level, String methodName, String facilityId, String... args) {

		print(getClassLogger(object), level.toString(), methodName + GLOBAL_LOG_MESSAGE_DELIMITER + "END" + GLOBAL_LOG_MESSAGE_DELIMITER + createAppMsgText(args)+"facilityID="+facilityId);

	}  
	
	/**
	 * 
	 * @param args
	 * @return
	 */
	protected  static String createAppMsgText(String... args){
		StringBuffer sb = new StringBuffer(256);
		for(String arg : args){
			sb.append(arg);
			sb.append(GLOBAL_LOG_MESSAGE_DELIMITER);
		}
		return sb.toString();
	}
	
	private static String getFacilityID(UserContextDTO userContextDTO) {
		return userContextDTO!=null?userContextDTO.getLoginFacilityID():null;
	}
}
