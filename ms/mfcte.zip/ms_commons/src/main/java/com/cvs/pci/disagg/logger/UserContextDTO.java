package com.cvs.pci.disagg.logger;


import java.util.TimeZone;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserContextDTO {

	private String loginFacilityID;

	private String partitionZone;
	
	private String hostName;
	private TimeZone loginFacilityTimezone;
	private String screenId;
	private String sessionNumber;

	private String ncpdID;
	
	private String facilityID;
	
	private String loginFacilityNum;
	
	private String timeZone;
	
	private String zipcode;
	
	private String statecode;
	
	private String dynamicIndicator;
	
	private String isPPIEnabled;
	
	private String isFacilityActive;
	
	private String ppiVersion;
	
	private String isMOSFacility;
	
	private String ddrZone;
}
