package com.cvs.pci.disagg.vo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CacheResponseVO  extends BaseCache  {

	
	@JsonProperty("statusCode")
	private int statusCode;

	@JsonProperty("status")
	private String status;

	@JsonProperty("description")
	private String description;
	

	@JsonProperty("data")
	private Object data ;
	
	@JsonProperty("type")
	private String type ;
	
	@JsonProperty("idxMiss")
	private List<String> missedEntry ;
	
	@JsonProperty("idxPushed")
	private List<String> pushlist ;
	
	public void  CacheResponseVO(int statusCode, String status, String description) {
		this.statusCode = statusCode;
		this.status = status;
		this.description = description;
	}
	
	public String getIdxKey() {
		return idxKey;
	}

	public void setIdxKey(String idxKey) {
		this.idxKey = idxKey;
	}
	
 
	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
 
	
	public List<String> getMissedEntry() {
		return missedEntry;
	}

	public void setMissedEntry(List<String> missedEntry) {
		this.missedEntry = missedEntry;
	}

	
	public List<String> getPushlist() {
		return pushlist;
	}

	public void setPushlist(List<String> pushlist) {
		this.pushlist = pushlist;
	}

	@Override
	public String toString() {
		return "CacheResponseVO [statusCode=" + statusCode + ", status=" + status + ", description=" + description
				+ ", data=" + data + ", type=" + type + ", missedEntry=" + missedEntry + ", pushlist=" + pushlist
				+ ", idxKey=" + idxKey + ", idxKeyGroup=" + idxKeyGroup + "]";
	}

}
